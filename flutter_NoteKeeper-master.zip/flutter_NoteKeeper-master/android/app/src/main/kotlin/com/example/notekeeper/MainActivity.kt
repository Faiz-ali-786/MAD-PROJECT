package com.example.notekeeper

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
