# notekeeper

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference. Splash screen
![PicsArt_01-08-07 50 53](https://user-images.githubusercontent.com/83277996/148667128-cd8dbf62-c42c-4714-a904-b5e3bbbdb43b.jpg)
homePage
![PicsArt_01-08-07 51 07](https://user-images.githubusercontent.com/83277996/148667130-d494c9bd-1db8-42b9-aecc-508ffcda162a.jpg)
Alertbox for adding data  
![PicsArt_01-08-07 51 24](https://user-images.githubusercontent.com/83277996/148667134-ac4b3246-ed27-450d-bafa-558634a6b771.jpg)
note keeper list
![PicsArt_01-08-07 51 38](https://user-images.githubusercontent.com/83277996/148667138-161e5135-1eac-43f6-bbc3-b6fba67efa0f.jpg)
deleting alertBox
![PicsArt_01-08-07 51 53](https://user-images.githubusercontent.com/83277996/148667144-5a1580de-44a8-4a02-95bb-fb9de1ad498f.jpg)
after updaing
![PicsArt_01-08-07 52 12](https://user-images.githubusercontent.com/83277996/148667149-25a007da-977b-4b56-8dcd-555c3a5d3bd7.jpg)
after deleting all data
![PicsArt_01-08-07 52 28](https://user-images.githubusercontent.com/83277996/148667152-45c7f1db-a3f1-41ab-95a9-98ef34957327.jpg)
detail Screen
 ![PicsArt_01-08-07 53 24](https://user-images.githubusercontent.com/83277996/148667292-8a5caf86-87f5-495e-bd66-37c501332314.jpg)
download the apk of note keeper
[app-release.zip](https://github.com/Codphobia/flutter_NoteKeeper/files/7834395/app-release.zip)


